﻿
var moonColor;      //name of our color chooser
var webrgb;         // last user chosen color in #rrggbb format
var defaultColor = "#ffffff";
window.addEventListener("load", startup, false);
function startup() {
    moonColor = document.querySelector("#moonColor");
    if ( moonColor == null ) {
        moonColor.value = defaultColor;
    }
    moonColor.addEventListener("input", updateFirst, false);
    moonColor.addEventListener("change", updateAll, false);
    moonColor.select();
}
function updateFirst(event) { // this will run on input.
    var input = document.querySelector("#moonColor");
    if (input) {
        webrgb = event.target.value;
        sendRGB();
        input.style.color = event.target.value;
        document.getElementById('moon').style.backgroundColor = event.target.value;
    }
}
function updateAll(event) { // runs after selection confirmed.
    var input = document.querySelector("#moonColor");
    if (input) {
        webrgb = event.target.value;
        sendRGB();
        input.style.color = event.target.value;
        document.getElementById('moon').style.backgroundColor = event.target.value;
    }
    // save prefs to fs for next boot.
}

var rainbowEnable = false;
var connection = new WebSocket('ws://'+location.hostname+':81/', ['arduino']);
connection.onopen = function () {
    connection.send('Connect ' + new Date());
};
connection.onerror = function (error) {
    console.log('WebSocket Error ', error);
};
connection.onmessage = function (e) {  
    console.log('Server: ', e.data);
};
connection.onclose = function(){
    console.log('WebSocket connection closed');
};
function sendRGB(){
    connection.send(webrgb);
}
function rainbowEffect(){
    rainbowEnable = ! rainbowEnable;
    if(rainbowEnable){
        connection.send("R");
        document.getElementById('rainbow').style.backgroundColor = '#00878F';
        document.getElementById('moonColor').className = 'disabled';
        document.getElementById('moonColor').disabled = true;
    } else {
        connection.send("N");
        document.getElementById('rainbow').style.backgroundColor = '#999';
        document.getElementById('moon').style.backgroundColor = moonColor;
        document.getElementById('moonColor').className = 'enabled';
        document.getElementById('moonColor').disabled = false;
        sendRGB();
    }  
}
function savePrefs(){
    connection.send("S");
}
