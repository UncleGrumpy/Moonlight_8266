var moonColor;      //name of our color chooser
var webrgb;         // last user chosen color in #rrggbb format
var defaultColor = "#ffffff";
window.addEventListener("load", startup, false);
function startup() {
    moonColor = document.querySelector("#moonColor");
    if ( moonColor == null ) {
        moonColor.value = defaultColor;
    }
    moonColor.addEventListener("input", updateFirst, false);
    moonColor.addEventListener("change", updateAll, false);
    moonColor.select();
}
function updateFirst(event) { // this will run on input.
    var input = document.querySelector("#moonColor");
    if (input) {
        webrgb = event.target.value;
        sendRGB();
        input.style.color = event.target.value;
        document.getElementById('moon').style.backgroundColor = event.target.value;
    }
}
function updateAll(event) { // runs after selection confirmed.
    var input = document.querySelector("#moonColor");
    if (input) {
        webrgb = event.target.value;
        sendRGB();
        input.style.color = event.target.value;
        document.getElementById('moon').style.backgroundColor = event.target.value;
    }
    // save prefs to fs for next boot.
}

var rainbowEnable = false;
var connection = new WebSocket('ws://'+location.hostname+':81/', ['arduino']);
connection.onopen = function () {
    connection.send('Connect ' + new Date());
};
connection.onerror = function (error) {
    console.log('WebSocket Error ', error);
};
connection.onmessage = function (e) {  
    console.log('Server: ', e.data);
};
connection.onclose = function(){
    console.log('WebSocket connection closed');
};
function sendRGB(){
// This is not working and has been temporarily moved to being decoded
// on the the server side in webSocketEvent() .
    
    // break into individual Hex values 
//     var wRed = webrgb.substring(1, 3);
//     var wGrn = webrgb.substring(3, 5);
//     var wBlu = webrgb.substring(5);
    // convert web HEX to decimal
//     var red = parseInt(wRed,16);
//     var grn = parseInt(wGrn,16);
//     var blu = parseInt(wBlu,16);

    // THE NEXT TWO CONVERSIONS CAN INSTEAD BE HANDLED BY ColorCorrect()
    // shfit scale (0-255) to analog (0-1024)
//     var aRed = red**2/64;
//     var aGrn = grn**2/64;
//     var aBlu = blu**2/64;
    // convert scale from linear to geometric.
//     var r = aRed**2/1023;
//     var g = aGrn**2/1023;
//     var b = aBlu**2/1023;

    // THE ColorCorrect FUNCTION HANDLES BOTH OF THE TWO PREVIOUS CONVERSIONS.
//     var r = ColorCorrect(red);
//     var g = ColorCorrect(grn);
//     var b = ColorCorrect(blu);
        
    // package data for websocket
//     var rgb = r << 20 | g << 10 | b;
//     var rgbstr = '#'+ rgb.toString(16);

    // send to server.
//     console.log('RGB: ' + rgbstr);
    connection.send(webrgb);
}
function rainbowEffect(){
    rainbowEnable = ! rainbowEnable;
    if(rainbowEnable){
        connection.send("R");
        document.getElementById('rainbow').style.backgroundColor = '#00878F';
        document.getElementById('moonColor').className = 'disabled';
        document.getElementById('moonColor').disabled = true;
    } else {
        connection.send("N");
        document.getElementById('rainbow').style.backgroundColor = '#999';
        document.getElementById('moon').style.backgroundColor = moonColor;
        document.getElementById('moonColor').className = 'enabled';
        document.getElementById('moonColor').disabled = false;
        sendRGB();
    }  
}
function ColorCorrect(v) {
    return Math.round((((v**2)/64)**2)/1023);
}
function savePrefs(){
    connection.send("S");
}
